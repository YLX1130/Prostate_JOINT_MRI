function [bvalue, wave] = bvalue_PGSE(duration, Delta, ramptime, gradient)
% input duration - PGSE gradient duration, in ms
%       Delta    - PGSE gradient separation
%       rampRatio - trapezoid PGSE gradient Ratio
%       gradient - PGSE gradient sqrt(Gx*Gx+Gy*Gy+Gz*Gz), in mT/m
% output bvalue, in s/m^2
%rampRatio = ramptime/duration 

% make the trapezoid PGSE waveform
Nt=6000;
rampRatio=ramptime*1e-3/duration;
plateau_len = floor(Nt*(1-2*rampRatio)+0.5);
ramp_len = floor(Nt*rampRatio);
Nt=plateau_len+2*ramp_len;
wave = zeros(Nt, 1);

tt=0;
for i=1:ramp_len
    wave(tt+i)=i/ramp_len;
end
tt=tt+ramp_len;
for i=1:plateau_len
    wave(tt+i)=1;
end
tt=tt+plateau_len;
for i=1:ramp_len
    wave(tt+i)=1-i/ramp_len;
end

%copy waveform
nt=floor(Nt+Nt/duration*Delta);
tmp=wave;
wave=zeros(nt,1);
wave(1:length(tmp))=tmp;
for i=Nt:nt
    if i<=floor(Nt/duration*Delta)
        wave(i)=0;
    else
        wave(i)=-wave(floor(i-floor(Nt/duration*Delta)));
    end
end
Nt=nt;


% calculate b value
dt = (duration+Delta)/Nt*1e-3; %in unit of second and wave is mT/m
wave=wave.*1e-3;

b = zeros(Nt,1);
for i = 1:Nt
    tmp = sum(wave(1:i))*dt; % internal integral
    b(i) = tmp^2*dt;
end

bvalue = sum(b)* (42.567*1e6*2*pi)^2 * (gradient^2) ;

