 function [bvalue, wave] = bvalue_tOGSE(frequency, duration, Delta,ramptime, gradient)
% input frequency - OGSE frequence, in Hz
%       duration - OGSE gradient duration, in ms
%       Delta    - OGSE gradient separation
%       ramptime - trapezoid OGSE gradient ramptime
%       gradient - OGSE gradient sqrt(Gx*Gx+Gy*Gy+Gz*Gz), in mT/m
%       time resolution=1 us
% output bvalue, in s/m^2
%rampRatio = ramptime/0.5cycletime =0.1

% make the trapezoid OGSE waveform
Nt = (duration+Delta)*1000;
cycle = round(duration*0.001*frequency);

tr=ramptime;
t3=ceil((duration*1000-(4*cycle+1)*tr)/(4*cycle));        %unit :us
tp=ceil(t3-0.5*tr);
    
wave = zeros(Nt, 1);

tt = 0;
if cycle==1
       for i=1:tr
           wave(tt+i)=(i-1)/tr;
       end
       tt=tt+tr;
       for i=1:tp
           wave(tt+i)=1;
       end
       tt=tt+tp;
       for i=1:2*tr
           wave(tt+i)=1-i/tr;
       end
       tt=tt+2*tr;
       for i=1:2*t3
           wave(tt+i)=-1;
       end
       tt=tt+2*t3;
       for i=1:2*tr
           wave(tt+i)=-1+i/tr;
       end
       tt=tt+2*tr;
       for i=1:tp
            wave(tt+i)=1;
       end
       tt=tt+tp;
       for i=1:tr
            wave(tt+i)=1-i/tr;
       end
       tt=tt+tr;
else
       for i=1:tr
           wave(tt+i)=i/tr;
       end
       tt=tt+tr;
       for i=1:tp
           wave(tt+i)=1;
       end
       tt=tt+tp;
       for i=1:2*tr
           wave(tt+i)=1-i/tr;
       end
       tt=tt+2*tr;
       for i=1:t3
           wave(tt+i)=-1;
       end
       tt=tt+t3;
       for j=1:cycle-1
            for i=1:t3
                wave(tt+i)=-1;
            end
            tt=tt+t3;
            for i=1:2*tr
                wave(tt+i)=-1+i/tr;
            end
            tt=tt+2*tr;
            for i=1:2*t3
                wave(tt+i)=1;
            end
            tt=tt+2*t3;
            for i=1:2*tr
                wave(tt+i)=1-i/tr;
            end
            tt=tt+2*tr;
            for i=1:t3
                wave(tt+i)=-1;
            end
            tt=tt+t3;
       end
       for i=1:t3
           wave(tt+i)=-1;
       end
       tt=tt+t3;
       for i=1:2*tr
           wave(tt+i)=-1+i/tr;
       end
       tt=tt+2*tr;
       for i=1:tp
            wave(tt+i)=1;
       end
       tt=tt+tp;
       for i=1:tr
            wave(tt+i)=1-i/tr;
       end
       tt=tt+tr;
end

%copy waveform
for i=1:(Delta-duration)*1000
    wave(tt+i)=0;
end
tt=tt+(Delta-duration)*1000;
for i=1:duration*1000
    wave(tt+i)=wave(tt+i-Delta*1000);
end

% calculate b value
dt = 1*1e-6;                   %in unit of us and wave is in unitless
wave=wave.*1e-3;

b = zeros(Nt,1);
parfor i = 1:Nt
    tmp = sum(wave(1:i))*dt; % internal integral
    b(i) = tmp^2*dt;
end

bvalue = sum(b)* (42.567*1e6*2*pi)^2 * (gradient^2) ;

%% According to Corey A. Baron paper
% f = 250; %unit Hz
% tramp = 0.1e-3; %unit s
% delta_eff = 1/6/f + 2/3*(tramp - tramp*tramp*f);
% N = 10; % # cycles before and after 180
% G = 400e-6; %unit mT/m --> T/mm 
% gamma = 42.576e6*2*pi; %unit rad/s/T
% bval = 2*N*gamma*gamma*G*G*(0.25/f - tramp/2)*(0.25/f - tramp/2)*delta_eff;
