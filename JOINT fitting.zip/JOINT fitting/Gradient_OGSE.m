function [gradient] = Gradient_OGSE(duration, Delta, frequency, bvalue,ramptime)
% input frequency - OGSE frequence, in Hz
%       duration - OGSE gradient duration, in ms
%       Delta  -  OGSE gradient separation
%       bvalue  - OGSE gradient in s/mm^2
% output gradient, in G/cm
b=bvalue_tOGSE(frequency,duration,Delta,ramptime,1);
gradient=sqrt(bvalue/b);