clear
clc
addpath '../NIFTI'
%% Generate DiffusionPulseSequence objects
smallDelta = [40 40 40 40 40 40 10 10 10 10 10 10 10 10]'*1e-3;           % Define diffusion duration for the OGSE50Hz, OGSE25Hz, and PGSE30ms, PGSE50ms scans
bigDelta = [50 50 50 50 50 50 30 30 30 30 50 50 50 50]'*1e-3;             % Define diffusion separation for the OGSE50Hz, OGSE25Hz, and PGSE30ms PGSE50ms scans
freq = [50 50 25 25 25 25 0 0 0 0 0 0 0 0]';                              % Define oscillating frequency for the OGSE50Hz, OGSE25Hz, and PGSE30ms PGSE50ms scans
bval = [150 300 250 500 750 1000 250 500 750 1000 250 500 750 1000]'*1e6; % Define b values for the OGSE50Hz, OGSE25Hz, and PGSE30ms PGSE50ms scans
ramptime = 1210*ones(length(bval),1); % ramp time=1.21ms
TE = 116*ones(length(bval),1); % TE=116ms
Grad=zeros(length(bval),1);
for i=1:length(freq)
    if freq(i)~=0
        Grad(i)=Gradient_OGSE(smallDelta(i)*1e3,bigDelta(i)*1e3,freq(i),bval(i),ramptime(i));
    else
        Grad(i)=Gradient_PGSE(smallDelta(i)*1e3,bigDelta(i)*1e3,bval(i),ramptime(i));
    end
end
Grad=Grad.*1e-3;
ramptime=ramptime*1e-6;
seqParams = [smallDelta, bigDelta, freq, Grad, bval,ramptime,TE];

Nrand = 100;                        % number of randomized initalization
f_init=linspace(0.1,0.9,100);       % Initalization for fin
diameter_init=linspace(1,30,100);   % Initalization for diameter
Dex_init=linspace(0.5,3,100);       % Initalization for Dex
Din_init=linspace(0.5,3,100);       % Initalization for Din
tin_init=linspace(1,100,100);       % note: here tin=1000/tauin

lim=[0,1,0.1,0.1,1; 
     1,40,3,3,100]; % lower and upper bound for fin, d, Dex, Din and tin
lb=lim(1,:);
ub=lim(2,:);
 
rician=false;
burns = 2000;
n_iter = 5000;

priori = {'flat','Lognorm','flat','flat','Lognorm'};
D_set = [0 300 0 0 300];
%% Preliminary 
% *** Better to perform dwidenoise and registration betweent the different DWIs before reading the data ***
scans_b = { 'og50_b150.nii','og50_b300.nii',...
    'og25_b250.nii','og25_b500.nii','og25_b750.nii','og25_b1000.nii',...
    'pg30_b250.nii','pg30_b500.nii','pg30_b750.nii','pg30_b1000.nii',...
    'pg50_b250.nii','pg50_b500.nii','pg50_b750.nii','pg50_b1000.nii'};

scans_b0 = { 'og50_b0.nii',...
    'og25_b0.nii',...
    'pg30_b0.nii',...
    'pg50_b0.nii'};

nbval = [2 4 4 4];

datapath = '/data/';
subjlist = dir(datapath);
subjlist(1:2) = '';

for m = 1 : length(subjlist)
    subjpath = [datapath,subjlist(m).name,'/'];
    nii = load_untouch_nii([subjpath,'ROI.nii']); % manually defined ROI
    nx = size(nii.img,1); ny = size(nii.img,2); nz = size(nii.img,3);
    mask = nii.img;
    nzIdx = find(mask>0);

    nii1 = nii;
    nii1.hdr.dime.dim(5)=1;
    nii1.hdr.dime.datatype=16;
    nii1.hdr.dime.bitpix=32;

    S0 = zeros(length(nzIdx),length(bval));
    S = zeros(length(nzIdx),length(bval));
    fin = zeros(length(nzIdx),1);
    diameter = zeros(length(nzIdx),1);
    Dex = zeros(length(nzIdx),1);
    Din = zeros(length(nzIdx),1);
    kin = zeros(length(nzIdx),1);
    
    
    for i = 1:length(scans_b)
        nii = load_untouch_nii([subjpath,scans_b{i}]); 
        data = nii.img;
        S(:,i) = data(nzIdx);  
    end
    
    i_start = 1; 
    for i = 1:length(scans_b0)    
        i_end = i_start + nbval(i) - 1;
        nii = load_untouch_nii([subjpath,scans_b0{i}]); 
        data = nii.img;
        S0(:,i_start:i_end) = repmat(data(nzIdx), [1 nbval(i)]);
        i_start = i_end + 1;
    end
   
    signal=S./(S0+1);

    %% lsqcurvefit fitting for S = JOINT_3(x, seqParams)
    % Randomly generated initial parameter values were used, and the smallest fitting residual were chosen as the NLLS results.
    f_fitted_lsq=zeros(size(nzIdx,1),1);
    diameter_fitted_lsq=zeros(size(nzIdx,1),1);
    Dex_fitted_lsq=zeros(size(nzIdx,1),1);
    Din_fitted_lsq=zeros(size(nzIdx,1),1);
    tin_fitted_lsq=zeros(size(nzIdx,1),1);
    cellularity_lsq=zeros(size(nzIdx,1),1);
    parfor i_voxel=1:size(nzIdx,1)
        residRMS = zeros(Nrand, 1);
        random_init = [randsample(f_init,Nrand); randsample(diameter_init,Nrand); randsample(Dex_init,Nrand); randsample(Din_init,Nrand); randsample(tin_init,Nrand)];
        ydata=signal(i_voxel,:)';
        fitParams = zeros(5, Nrand);
        for k=1:Nrand
            x0=random_init(:,k);
            [x,~,residual] = lsqcurvefit(@JOINT_3,x0,seqParams,ydata,lb,ub);
            residRMS(k) = sqrt(mean(residual.^2));
            fitParams(:,k) = x;
        end
        [~, idx] = min(residRMS);
        f_fitted_lsq(i_voxel) = fitParams(1, idx);
        diameter_fitted_lsq(i_voxel) = fitParams(2, idx);
        Dex_fitted_lsq(i_voxel) = fitParams(3, idx);
        Din_fitted_lsq(i_voxel) = fitParams(4, idx);
        tin_fitted_lsq(i_voxel) = fitParams(5, idx);
        
        RMS(i_voxel)=residRMS(idx);
    end

    mapdir = [subjpath,'/',['diameter_',priori{2},'_tauin_',priori{5}],'/'];
    mkdir(mapdir)
    
    %% bayesian fitting for S = Bayes_Joint(x, seqParams) 
    % The results of NLLS as Initalization
    out_micro = zeros(size(signal,1),5);
    parfor i_voxel = 1:length(nzIdx)
        f_init = f_fitted_lsq(i_voxel);
        Dex_init = Dex_fitted_lsq(i_voxel);  
        Din_init = Din_fitted_lsq(i_voxel);
        d_init = diameter_fitted_lsq(i_voxel);
        tin_init = tin_fitted_lsq(i_voxel);    
        E = [f_fitted_lsq(i_voxel),20,Dex_fitted_lsq(i_voxel),Din_fitted_lsq(i_voxel),10];
        sig_voxel = signal(i_voxel,:);
        if strcmp(priori{2},'Lognorm') || strcmp(priori{2},'Gaussian') || strcmp(priori{5},'Lognorm') || strcmp(priori{5},'Gaussian')
            priori_special = priori;
            if E(2) < 3 || E(2) > 35 
                priori_special{2} = 'reci';        
            end 
            if E(5) < 3 || E(5) > 80 
                priori_special{5} = 'reci';        
            end 
            out = Bayes_Joint(sig_voxel, f_init,d_init,Dex_init,Din_init,tin_init,seqParams,lim,n_iter,priori_special,burns,E,D_set);
        else
            out = Bayes_Joint(sig_voxel, f_init,d_init,Dex_init,Din_init,tin_init,seqParams,lim,n_iter,priori,burns,E,D_set);
        end
        out_micro(i_voxel,:,1) = [out.f.mean, out.diameter.mean, out.Dex.mean,out.Din.mean,out.tin.mean];
        
    end
    
    %% save the data
    fin_out = zeros(nx,ny,nz);
    diameter_out = fin_out;
    Dex_out = fin_out;
    Cellularity_out=fin_out;
    Din_out = fin_out;
    tauin_out = fin_out;
    tauex_out = fin_out;
    
    % fin 
    fin_out(nzIdx) = out_micro(:,1);
    nii1.img = fin_out;
    save_untouch_nii(nii1,[mapdir,'/fin_joint.nii'])
    
    % diameter
    diameter_out(nzIdx) = out_micro(:,2);
    nii1.img = diameter_out;
    save_untouch_nii(nii1,[mapdir,'/diameter_joint.nii'])
    
    % Dex
    Dex_out(nzIdx) = out_micro(:,3);
    nii1.img = Dex_out;
    save_untouch_nii(nii1,[mapdir,'/Dex_joint.nii'])
    
    % Cellularity
    Cellularity_out(nzIdx) = out_micro(:,1)./out_micro(:,2)*100;
    nii1.img = Cellularity_out;
    save_untouch_nii(nii1,[mapdir,'/Cellularity_joint.nii'])       
   
    % Din
    Din_out(nzIdx) = out_micro(:,4);
    nii1.img = Din_out;
    save_untouch_nii(nii1,[mapdir,'/Din_joint.nii'])

    % tauin
    tauin_out(nzIdx) = out_micro(:,5);
    nii1.img = 1000./tauin_out;
    save_untouch_nii(nii1,[mapdir,'/tauin_joint.nii'])
    
    % tauex
    tauex_out(nzIdx) = (1-out_micro(:,1))./out_micro(:,5)*1000;
    nii1.img = tauex_out;
    save_untouch_nii(nii1,[mapdir,'/tauex_joint.nii'])       

end







