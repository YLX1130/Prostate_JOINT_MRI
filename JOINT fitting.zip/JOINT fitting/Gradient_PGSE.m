function [gradient] = Gradient_PGSE(duration, Delta, bvalue,ramptime)
% input
%       duration - PGSE gradient duration, in ms
%       Delta  -  PGSE gradient separation
%       bvalue  - PGSE gradient in s/mm^2
% output gradient, in G/cm
b=bvalue_PGSE(duration,Delta,ramptime,1);
gradient=sqrt(bvalue/b);