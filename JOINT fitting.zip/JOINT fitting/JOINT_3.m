function S = JOINT_3(x, seqParams)
% x = [fin, diameter, Dex , Din, kin];
%       x(1)  x(2)   x(3)  x(4)  x(5)
% seqParams = [smallDelta, bigDelta, freq, Grad, bval,ramptime,TE];
%               p(1)        p(2)     p(3)   p(4)  p(5) p(6) p(7)
% grad in unit of T/m
% diameter in unit of meter
% Din, Dex in unit of m^2/s
% smallDelta and bigDelta in unit of second

%Din = 1e-9;
vin = x(1);
kin = x(5)*1e-3;
kex=vin.*kin./(1-vin);

E = JOINT_IMPULSED_3([1,x(2),x(3),x(4)], seqParams(:,1:6));
ADC = -log(E)./seqParams(:,5)*1e9;
S = zeros(size(seqParams, 1), 1);
for k = 1:size(seqParams, 1)
    N = round(seqParams(k,1)*seqParams(k,3));
    if N > 0
        S(k) = JOINT_IMPULSED_3([x(1),x(2),x(3),x(4)], seqParams(k,1:6));
    elseif N == 0
        tdiff = seqParams(k,2) - seqParams(k,1)/3;
        tdiff = tdiff*1e3;
        TE = seqParams(k,7);
        tg1 = (TE - tdiff)/2;
        tg2 = tg1 + tdiff;
        tg3 = TE;
        [ M_in_tg1, M_ex_tg1 ] = generalSolution_blochEQ( kin,kex,kin,kex,vin,1-vin,tg1 );
        Ain=kin+seqParams(k,5)*1e-9/tdiff.*ADC(k);
        Aex=kex+seqParams(k,5)*1e-9./tdiff.*x(3);
        [ M_in_tg2, M_ex_tg2 ] = generalSolution_blochEQ( Ain,Aex,kin,kex,M_in_tg1,M_ex_tg1,tg2-tg1 );
        [ M_in_tg3, M_ex_tg3 ] = generalSolution_blochEQ( kin,kex,kin,kex,M_in_tg2,M_ex_tg2,tg3-tg2 );
        S(k) = (M_in_tg3+M_ex_tg3);
    end
end
end

function [ M_in, M_ex ] = generalSolution_blochEQ( Ain,Aex,kin,kex,Min0,Mex0,t )
Q=sqrt((Ain-Aex).^2+4.*kin.*kex);
R1=(Ain+Aex-Q)/2;
R2=(Ain+Aex+Q)/2;
M_in=((Aex-Ain+Q).*Min0+2.*kex.*Mex0)/2./Q.*exp(-R1.*t)+((-Aex+Ain+Q).*Min0-2.*kex.*Mex0)/2./Q.*exp(-R2.*t);
M_ex=((-Aex+Ain+Q).*Mex0+2.*kin.*Min0)/2./Q.*exp(-R1.*t)+((Aex-Ain+Q).*Mex0-2.*kin.*Min0)/2./Q.*exp(-R2.*t);
if length(kin)>1
    M_in(:,find(kin==0)|find(kex==0))=Min0.*exp(-(Ain-kin).*t);
    M_ex(:,find(kin==0)|find(kex==0))=Mex0.*exp(-(Aex-kex).*t);
else
    if kin==0 | kex==0
        M_in=Min0.*exp(-(Ain-kin).*t);
        M_ex=Mex0.*exp(-(Aex-kex).*t);
    end        
end
end
